import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const Profile = () => {
  const { user, updateProfile } = useAuth();
  const [formData, setFormData] = useState({
    name: user?.name || '',
    age: user?.age || '',
    gender: user?.gender || 'other',
    height: user?.height || '',
    weight: user?.weight || '',
    fitnessGoals: user?.fitnessGoals?.join(', ') || ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const updateData = { ...formData };
    
    // Convert numeric fields
    if (updateData.age) updateData.age = parseInt(updateData.age);
    if (updateData.height) updateData.height = parseFloat(updateData.height);
    if (updateData.weight) updateData.weight = parseFloat(updateData.weight);
    
    // Convert fitness goals to array
    if (updateData.fitnessGoals) {
      updateData.fitnessGoals = updateData.fitnessGoals
        .split(',')
        .map(goal => goal.trim())
        .filter(goal => goal.length > 0);
    }

    const result = await updateProfile(updateData);
    setLoading(false);
  };

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h1>Profile Settings</h1>
        <p>Update your personal information and fitness details</p>
      </div>
      
      <div className="profile-card">
        <form onSubmit={handleSubmit} className="profile-form">
          <div className="form-section">
            <h3>Personal Information</h3>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="name">Full Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="form-input"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="age">Age</label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={formData.age}
                  onChange={handleChange}
                  className="form-input"
                  min="13"
                  max="120"
                />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="gender">Gender</label>
              <select
                id="gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="form-input"
              >
                <option value="other">Prefer not to say</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>
          
          <div className="form-section">
            <h3>Physical Information</h3>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="height">Height (cm)</label>
                <input
                  type="number"
                  id="height"
                  name="height"
                  value={formData.height}
                  onChange={handleChange}
                  className="form-input"
                  min="50"
                  step="0.1"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="weight">Weight (kg)</label>
                <input
                  type="number"
                  id="weight"
                  name="weight"
                  value={formData.weight}
                  onChange={handleChange}
                  className="form-input"
                  min="20"
                  step="0.1"
                />
              </div>
            </div>
          </div>
          
          <div className="form-section">
            <h3>Fitness Goals</h3>
            
            <div className="form-group">
              <label htmlFor="fitnessGoals">Goals (comma-separated)</label>
              <textarea
                id="fitnessGoals"
                name="fitnessGoals"
                value={formData.fitnessGoals}
                onChange={handleChange}
                placeholder="e.g., Lose weight, Build muscle, Run a marathon"
                className="form-textarea"
                rows="3"
              />
            </div>
          </div>
          
          <button 
            type="submit" 
            disabled={loading}
            className="profile-button"
          >
            {loading ? 'Updating...' : 'Update Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;