import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Welcome back, {user?.name}!</h1>
        <p>Track your fitness journey and achieve your goals</p>
      </div>
      
      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h3>Profile Overview</h3>
          <div className="profile-stats">
            <div className="stat">
              <span className="stat-label">Age:</span>
              <span className="stat-value">{user?.age || 'Not set'}</span>
            </div>
            <div className="stat">
              <span className="stat-label">Height:</span>
              <span className="stat-value">{user?.height ? `${user.height} cm` : 'Not set'}</span>
            </div>
            <div className="stat">
              <span className="stat-label">Weight:</span>
              <span className="stat-value">{user?.weight ? `${user.weight} kg` : 'Not set'}</span>
            </div>
            <div className="stat">
              <span className="stat-label">Gender:</span>
              <span className="stat-value">{user?.gender || 'Not specified'}</span>
            </div>
          </div>
        </div>
        
        <div className="dashboard-card">
          <h3>Quick Actions</h3>
          <div className="quick-actions">
            <button className="action-btn">Log Workout</button>
            <button className="action-btn">Track Nutrition</button>
            <button className="action-btn">View Progress</button>
            <button className="action-btn">Set Goals</button>
          </div>
        </div>
        
        <div className="dashboard-card">
          <h3>Recent Activity</h3>
          <div className="activity-list">
            <p className="no-activity">No recent activities. Start your fitness journey today!</p>
          </div>
        </div>
        
        <div className="dashboard-card">
          <h3>Fitness Goals</h3>
          <div className="goals-list">
            {user?.fitnessGoals?.length > 0 ? (
              user.fitnessGoals.map((goal, index) => (
                <div key={index} className="goal-item">
                  {goal}
                </div>
              ))
            ) : (
              <p className="no-goals">No fitness goals set. Set your goals to get started!</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;