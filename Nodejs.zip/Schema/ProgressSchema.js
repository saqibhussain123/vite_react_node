import mongoose from 'mongoose';

const progressSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  weight: {
    type: Number,
    default: null
  },
  bodyFat: {
    type: Number,
    default: null
  },
  muscle: {
    type: Number,
    default: null
  },
  measurements: {
    chest: {
      type: Number,
      default: null
    },
    waist: {
      type: Number,
      default: null
    },
    hips: {
      type: Number,
      default: null
    },
    arms: {
      type: Number,
      default: null
    },
    thighs: {
      type: Number,
      default: null
    }
  },
  notes: {
    type: String,
    default: ''
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

export default mongoose.model('Progress', progressSchema);