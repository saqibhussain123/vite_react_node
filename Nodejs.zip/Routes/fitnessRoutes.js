import express from 'express';
import {
  createWorkout,
  getWorkouts,
  updateWorkout,
  deleteWorkout,
  createNutrition,
  getNutrition,
  updateNutrition,
  deleteNutrition,
  createProgress,
  getProgress,
  updateProgress,
  deleteProgress
} from '../controller/FitnessController.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Workout routes
router.post('/workouts', auth, createWorkout);
router.get('/workouts', auth, getWorkouts);
router.put('/workouts/:id', auth, updateWorkout);
router.delete('/workouts/:id', auth, deleteWorkout);

// Nutrition routes
router.post('/nutrition', auth, createNutrition);
router.get('/nutrition', auth, getNutrition);
router.put('/nutrition/:id', auth, updateNutrition);
router.delete('/nutrition/:id', auth, deleteNutrition);

// Progress routes
router.post('/progress', auth, createProgress);
router.get('/progress', auth, getProgress);
router.put('/progress/:id', auth, updateProgress);
router.delete('/progress/:id', auth, deleteProgress);

export default router;