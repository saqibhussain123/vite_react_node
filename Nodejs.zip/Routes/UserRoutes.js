import express from 'express';
import { 
  registerUser, 
  loginUser, 
  getUsers, 
  getUserProfile,
  updateProfile,
  upload 
} from '../controller/Usercontroller.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.post('/register', upload.single('profileImage'), registerUser);
router.post('/login', loginUser);

// Protected routes
router.get('/getUsers', auth, getUsers);
router.get('/profile', auth, getUserProfile);
router.put('/profile', auth, upload.single('profileImage'), updateProfile);

export default router;