import express from 'express';
import {
  getAllUsers,
  getUserDetails,
  deleteUser,
  updateUserRole,
  getAdminStats
} from '../controller/AdminController.js'; // ✅ CORRECT PATH

import { adminAuth } from '../middleware/adminAuth.js';

const router = express.Router();

// Admin dashboard stats
router.get('/stats', adminAuth, getAdminStats);

// User management routes
router.get('/users', adminAuth, getAllUsers);
router.get('/users/:userId', adminAuth, getUserDetails);
router.delete('/users/:userId', adminAuth, deleteUser);
router.put('/users/:userId/role', adminAuth, updateUserRole);

export default router;
