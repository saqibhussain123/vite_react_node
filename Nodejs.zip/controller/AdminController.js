import User from '../Schema/UserSchema.js';
import Workout from '../Schema/WorkoutSchema.js';
import Nutrition from '../Schema/NutritionSchema.js';
import Progress from '../Schema/ProgressSchema.js';

// Get all users (Admin only)
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({ users });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get user details with fitness data (Admin only)
export const getUserDetails = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const workouts = await Workout.find({ userId: req.params.userId }).sort({ createdAt: -1 });
    const nutrition = await Nutrition.find({ userId: req.params.userId }).sort({ createdAt: -1 });
    const progress = await Progress.find({ userId: req.params.userId }).sort({ createdAt: -1 });

    res.json({
      user,
      fitnessData: {
        workouts,
        nutrition,
        progress
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete user (Admin only)
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Also delete all user's fitness data
    await Workout.deleteMany({ userId: req.params.userId });
    await Nutrition.deleteMany({ userId: req.params.userId });
    await Progress.deleteMany({ userId: req.params.userId });

    res.json({ message: 'User and all associated data deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update user role (Admin only)
export const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { role },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User role updated successfully', user });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get admin dashboard stats
export const getAdminStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalAdmins = await User.countDocuments({ role: 'admin' });
    const totalWorkouts = await Workout.countDocuments();
    const totalNutritionEntries = await Nutrition.countDocuments();
    const totalProgressEntries = await Progress.countDocuments();

    // Get recent registrations (last 7 days)
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const recentUsers = await User.countDocuments({ createdAt: { $gte: weekAgo } });

    res.json({
      stats: {
        totalUsers,
        totalAdmins,
        totalWorkouts,
        totalNutritionEntries,
        totalProgressEntries,
        recentUsers
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};