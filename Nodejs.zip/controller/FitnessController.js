import Workout from '../Schema/WorkoutSchema.js';
import Nutrition from '../Schema/NutritionSchema.js';
import Progress from '../Schema/ProgressSchema.js';

// Workout Controllers
export const createWorkout = async (req, res) => {
  try {
    const workout = new Workout({
      ...req.body,
      userId: req.user.id
    });
    await workout.save();
    res.status(201).json({ message: 'Workout created successfully', workout });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getWorkouts = async (req, res) => {
  try {
    const workouts = await Workout.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json({ workouts });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateWorkout = async (req, res) => {
  try {
    const workout = await Workout.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.id },
      req.body,
      { new: true }
    );
    if (!workout) {
      return res.status(404).json({ error: 'Workout not found' });
    }
    res.json({ message: 'Workout updated successfully', workout });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteWorkout = async (req, res) => {
  try {
    const workout = await Workout.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    if (!workout) {
      return res.status(404).json({ error: 'Workout not found' });
    }
    res.json({ message: 'Workout deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Nutrition Controllers
export const createNutrition = async (req, res) => {
  try {
    const nutrition = new Nutrition({
      ...req.body,
      userId: req.user.id
    });
    await nutrition.save();
    res.status(201).json({ message: 'Nutrition entry created successfully', nutrition });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getNutrition = async (req, res) => {
  try {
    const nutrition = await Nutrition.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json({ nutrition });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateNutrition = async (req, res) => {
  try {
    const nutrition = await Nutrition.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.id },
      req.body,
      { new: true }
    );
    if (!nutrition) {
      return res.status(404).json({ error: 'Nutrition entry not found' });
    }
    res.json({ message: 'Nutrition entry updated successfully', nutrition });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteNutrition = async (req, res) => {
  try {
    const nutrition = await Nutrition.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    if (!nutrition) {
      return res.status(404).json({ error: 'Nutrition entry not found' });
    }
    res.json({ message: 'Nutrition entry deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Progress Controllers
export const createProgress = async (req, res) => {
  try {
    const progress = new Progress({
      ...req.body,
      userId: req.user.id
    });
    await progress.save();
    res.status(201).json({ message: 'Progress entry created successfully', progress });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getProgress = async (req, res) => {
  try {
    const progress = await Progress.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json({ progress });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateProgress = async (req, res) => {
  try {
    const progress = await Progress.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.id },
      req.body,
      { new: true }
    );
    if (!progress) {
      return res.status(404).json({ error: 'Progress entry not found' });
    }
    res.json({ message: 'Progress entry updated successfully', progress });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteProgress = async (req, res) => {
  try {
    const progress = await Progress.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    if (!progress) {
      return res.status(404).json({ error: 'Progress entry not found' });
    }
    res.json({ message: 'Progress entry deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};