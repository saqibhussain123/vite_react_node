import User from '../Schema/UserSchema.js';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Create unique filename with original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, uniqueSuffix + ext);
  }
});

// File filter function
const fileFilter = (req, file, cb) => {
  // Accept only image files
  const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, JPG and GIF are allowed.'), false);
  }
};

// Configure multer upload
export const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: fileFilter
});

export const registerUser = async (req, res) => {
  console.log(req.body);
  
  try {
    const { username, email, password } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { username }] 
    });
    
    if (existingUser) {
      // Remove uploaded file if user already exists
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      
      if (existingUser.email === email) {
        return res.status(400).json({ error: 'Email already in use' });
      } else {
        return res.status(400).json({ error: 'Username already taken' });
      }
    }

    // Create new user with profile image if uploaded
    const user = new User({
      username,
      email,
      password,
      profileImage: req.file ? `/uploads/${req.file.filename}` : ''
    });

    await user.save();
    
    // Don't send password in response
    const userResponse = {
      _id: user._id,
      username: user.username,
      email: user.email,
      profileImage: user.profileImage
    };
    
    res.status(201).json({ 
      message: 'User registered successfully', 
      user: userResponse 
    });
  } catch (err) {
    // Remove uploaded file if registration fails
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(400).json({ error: err.message });
  }
};

export const loginUser = async (req, res) => {
  try {
    console.log(req.body);
    
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = user.generateAuthToken();
    
    // Don't send password in response
    const userResponse = {
      _id: user._id,
      username: user.username,
      email: user.email,
      profileImage: user.profileImage
    };
    
    res.json({ 
      message: 'Login successful', 
      user: userResponse, 
      token 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getUsers = async (req, res) => {
  try {
    // Don't send passwords in response
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getUserProfile = async (req, res) => {
  try {
    // Get user from auth middleware
    const user = await User.findById(req.user.id).select('-password');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const updateProfile = async (req, res) => {
  try {
    const { username, email } = req.body;
    const userId = req.user.id;
    
    // Check for existing username/email if they are changed
    if (username || email) {
      const existingUser = await User.findOne({
        $and: [
          { _id: { $ne: userId } },
          { $or: [
            { username: username || '' },
            { email: email || '' }
          ]}
        ]
      });
      
      if (existingUser) {
        // Remove uploaded file if user update fails
        if (req.file) {
          fs.unlinkSync(req.file.path);
        }
        
        if (existingUser.email === email) {
          return res.status(400).json({ error: 'Email already in use' });
        } else {
          return res.status(400).json({ error: 'Username already taken' });
        }
      }
    }
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      // Remove uploaded file if user not found
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update user fields if provided
    if (username) user.username = username;
    if (email) user.email = email;
    
    // Update profile image if provided
    if (req.file) {
      // Remove old profile image if it exists
      if (user.profileImage) {
        const oldImagePath = path.join(__dirname, '..', user.profileImage);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      }
      
      user.profileImage = `/uploads/${req.file.filename}`;
    }
    
    await user.save();
    
    // Don't send password in response
    const userResponse = {
      _id: user._id,
      username: user.username,
      email: user.email,
      profileImage: user.profileImage
    };
    
    res.json({ 
      message: 'Profile updated successfully', 
      user: userResponse 
    });
  } catch (err) {
    // Remove uploaded file if update fails
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(400).json({ error: err.message });
  }
};