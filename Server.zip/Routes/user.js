const express = require('express');
const User = require('./public/uploads/auth');
const auth = require('../middleware/auth');

const router = express.Router();

// Update user profile
router.put('/profile', auth, async (req, res) => {
  try {
    const updates = req.body;
    const allowedUpdates = ['name', 'age', 'gender', 'height', 'weight', 'fitnessGoals', 'profilePicture'];
    const actualUpdates = {};

    // Filter allowed updates
    Object.keys(updates).forEach(update => {
      if (allowedUpdates.includes(update)) {
        actualUpdates[update] = updates[update];
      }
    });

    const user = await User.findByIdAndUpdate(
      req.userId,
      actualUpdates,
      { new: true, runValidators: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: 'Profile updated successfully',
      user
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({ message: messages.join('. ') });
    }
    
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;