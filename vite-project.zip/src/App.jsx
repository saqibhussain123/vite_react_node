import React, { useState } from 'react';
import { AuthProvider, useAuth } from '../src/context/src/context/AuthContext';
import ProtectedRoute from './components/Auth/ProtectedRoute';
import LoginForm from './components/Auth/LoginForm';
import SignupForm from './components/Auth/SignupForm';
import Navbar from './components/Layout/Navbar';
import Dashboard from './components/Dashboard/Dashboard';
import WorkoutTracker from './components/Fitness/WorkoutTracker';
import NutritionTracker from './components/Fitness/NutritionTracker';
import ProgressTracker from './components/Fitness/ProgressTracker';
import AdminDashboard from './components/Admin/AdminDashboard';

// Dark mode detection
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
  document.documentElement.classList.add('dark');
}

const FitnessApp = () => {
  const { user, loading } = useAuth();
  const [currentRoute, setCurrentRoute] = useState('dashboard');
  const [authRoute, setAuthRoute] = useState('login');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-2xl font-medium">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return authRoute === 'login' ? 
      <LoginForm onRouteChange={setAuthRoute} /> : 
      <SignupForm onRouteChange={setAuthRoute} />;
  }

  const renderCurrentRoute = () => {
    switch (currentRoute) {
      case 'workouts':
        return <WorkoutTracker />;
      case 'nutrition':
        return <NutritionTracker />;
      case 'progress':
        return <ProgressTracker />;
      case 'admin':
        return user.role === 'admin' ? <AdminDashboard /> : <Dashboard />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar currentRoute={currentRoute} onRouteChange={setCurrentRoute} />
      <main className="pt-16">
        <ProtectedRoute>
          {renderCurrentRoute()}
        </ProtectedRoute>
      </main>
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <FitnessApp />
    </AuthProvider>
  );
};

export default App;