import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

// About Us Page Component
const About = () => {
  return (
    <div className="about-us" style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2.5em' }}>About Us</h1>
      <p style={{ fontSize: '1.2em', lineHeight: '1.6' }}>
        Welcome to our company! We are passionate about delivering the best products and services to our customers.
      </p>
      
      <section style={{ marginTop: '20px' }}>
        <h2>Our Mission</h2>
        <p style={{ fontSize: '1.2em' }}>
          Our mission is to revolutionize the industry by providing innovative and sustainable solutions that make a positive impact on people's lives.
        </p>
      </section>

      <section style={{ marginTop: '20px' }}>
        <h2>Our Values</h2>
        <ul style={{ listStyleType: 'none', padding: '0' }}>
          <li style={{ margin: '10px 0', fontSize: '1.2em' }}>
            <strong>Integrity:</strong> We always do the right thing.
          </li>
          <li style={{ margin: '10px 0', fontSize: '1.2em' }}>
            <strong>Customer Satisfaction:</strong> We prioritize our customers' needs.
          </li>
          <li style={{ margin: '10px 0', fontSize: '1.2em' }}>
            <strong>Innovation:</strong> We are constantly evolving and improving.
          </li>
          <li style={{ margin: '10px 0', fontSize: '1.2em' }}>
            <strong>Sustainability:</strong> We aim to build a better future.
          </li>
        </ul>
      </section>

      <section style={{ marginTop: '20px' }}>
        <h2>Our Team</h2>
        <p style={{ fontSize: '1.2em' }}>
          We have a diverse and talented team that is dedicated to making a difference. Our team works together to achieve our vision and goals.
        </p>
      </section>
    </div>
  );
};

// Main App Component with Routing
const App = () => {
  const navItems = ["Home", "About"];

  return (
    <Router>
      <div className="App">
        <nav>
          <ul className="nav" style={{ listStyleType: 'none', padding: '0', display: 'flex' }}>
            {navItems.map((item, index) => (
              <li key={index} className="nav-item" style={{ marginRight: '20px' }}>
                <Link to={`/${item.toLowerCase()}`} className="nav-link" style={{ textDecoration: 'none', fontSize: '1.2em' }}>
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<h2>Home Page</h2>} />
          <Route path="/about" element={<About />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
