import React from 'react';

const Footer = () => {
  const styles = {
    footer: {
      backgroundColor: '#1e1e1e',
      color: '#ffffff',
      textAlign: 'center',
      padding: '2rem 1rem',
      position: 'relative',
      bottom: 0,
      width: '100%',
    },
    heading: {
      marginBottom: '0.5rem',
    },
    links: {
      marginTop: '1rem',
    },
    link: {
      color: '#ffffff',
      margin: '0 0.8rem',
      textDecoration: 'none',
    },
    linkHover: {
      color: '#00bcd4',
    },
  };

  return (
    <footer style={styles.footer}>
      <h3 style={styles.heading}>Your Company</h3>
      <p>© {new Date().getFullYear()} All rights reserved.</p>
      <div style={styles.links}>
        <a href="/about" style={styles.link}>About</a>
        <a href="/services" style={styles.link}>Services</a>
        <a href="/contact" style={styles.link}>Contact</a>
      </div>
    </footer>
  );
};

export default Footer;
