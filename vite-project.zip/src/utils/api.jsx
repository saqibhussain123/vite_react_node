const API_BASE = 'http://localhost:6969/api';

// Helper function to get auth headers
const getAuthHeaders = () => {
  const token = localStorage.getItem('fitness_token');
  return {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` })
  };
};

export const api = {
  // Auth APIs
  register: async (userData) => {
    const formData = new FormData();
    Object.keys(userData).forEach(key => {
      if (userData[key] !== null) {
        formData.append(key, userData[key]);
      }
    });

    const response = await fetch(`${API_BASE}/users/register`, {
      method: 'POST',
      body: formData
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Registration failed');
    }
    return data;
  },

  login: async (credentials) => {
    const response = await fetch(`${API_BASE}/users/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Login failed');
    }
    return data;
  },

  // Fitness APIs
  getWorkouts: async () => {
    const response = await fetch(`${API_BASE}/fitness/workouts`, {
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.workouts;
  },

  createWorkout: async (workoutData) => {
    const response = await fetch(`${API_BASE}/fitness/workouts`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(workoutData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.workout;
  },

  getNutrition: async () => {
    const response = await fetch(`${API_BASE}/fitness/nutrition`, {
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.nutrition;
  },

  createNutrition: async (nutritionData) => {
    const response = await fetch(`${API_BASE}/fitness/nutrition`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(nutritionData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.nutrition;
  },

  getProgress: async () => {
    const response = await fetch(`${API_BASE}/fitness/progress`, {
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.progress;
  },

  createProgress: async (progressData) => {
    const response = await fetch(`${API_BASE}/fitness/progress`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(progressData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.progress;
  },

  // Admin APIs
  getAdminStats: async () => {
    const response = await fetch(`${API_BASE}/admin/stats`, {
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.stats;
  },

  getAllUsers: async () => {
    const response = await fetch(`${API_BASE}/admin/users`, {
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data.users;
  },

  deleteUser: async (userId) => {
    const response = await fetch(`${API_BASE}/admin/users/${userId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data;
  },

  updateUserRole: async (userId, role) => {
    const response = await fetch(`${API_BASE}/admin/users/${userId}/role`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ role })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data;
  }
};

export default api;