import React, { createContext, useState, useEffect, useContext } from 'react';
import storage from '../../../utils/storage';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = storage.get('fitness_token');
    const userData = storage.get('fitness_user');
    if (token && userData) {
      setUser(userData);
    }
    setLoading(false);
  }, []);

  const login = (userData, token) => {
    setUser(userData);
    storage.set('fitness_user', userData);
    storage.set('fitness_token', token);
  };

  const logout = () => {
    setUser(null);
    storage.remove('fitness_token');
    storage.remove('fitness_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);