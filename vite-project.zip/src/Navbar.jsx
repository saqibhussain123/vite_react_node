import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  AppBar,
  Box,
  Toolbar,
  Typography,
  IconButton,
  Button,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Divider,
  useMediaQuery,
  Avatar,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import LogoutIcon from "@mui/icons-material/Logout";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const isMobile = useMediaQuery("(max-width:768px)");
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const serverUrl = "http://localhost:6969";

  useEffect(() => {
    // Get user data from localStorage
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);
    }
  }, []);

  const navItems = [
    { text: "Home", route: "/" },
    { text: "Card", route: "/card" },
    { text: "About", route: "/about" },
    { text: "Contact", route: "/contact" },
  ];

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("profilePic");
    setUser(null);
    navigate("/login");
  };

  // Profile image display logic
  const renderProfileImage = () => {
    if (user?.profileImage) {
      return (
        <Avatar 
          src={`${serverUrl}${user.profileImage}`} 
          alt={user.username}
          sx={{ 
            width: 40, 
            height: 40,
            border: '2px solid #fff'
          }}
        />
      );
    } else {
      return (
        <AccountCircleIcon 
          sx={{ 
            color: 'white',
            width: 40,
            height: 40
          }} 
        />
      );
    }
  };
  // In your Navbar component, add logic to show admin links only for admin users
// Example:
const Admin = JSON.parse(localStorage.getItem('Admin'));
const isAdmin = Admin && Admin.role === 'admin';

// Then in your JSX:
{isAdmin && (
  <Button color="inherit" component={Link} to="/admin/dashboard">
    Admin Dashboard
  </Button>
)}

  return (
    <AppBar sx={{ background: "#1976d2" }}>
      <Toolbar>
        <Typography
          variant="h6"
          sx={{ flexGrow: 1, fontWeight: "bold", cursor: "pointer" }}
          onClick={() => navigate("/")}
        >
          MyTodoApp
        </Typography>

        {isMobile ? (
          <>
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => setDrawerOpen(true)}
            >
              <MenuIcon />
            </IconButton>
            <Drawer
              anchor="left"
              open={drawerOpen}
              onClose={() => setDrawerOpen(false)}
            >
              <Box sx={{ width: 250, p: 2 }}>
                <List>
                  {navItems.map((item) => (
                    <ListItem
                      button
                      key={item.text}
                      component={Link}
                      to={item.route}
                      onClick={() => setDrawerOpen(false)}
                    >
                      <ListItemText primary={item.text} />
                    </ListItem>
                  ))}
                  <Divider sx={{ my: 1 }} />

                  {user ? (
                    <>
                      <ListItem>
                        <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          {renderProfileImage()}
                          <ListItemText 
                            primary={`Hello, ${user.username}`} 
                            sx={{ ml: 1 }}
                          />
                        </Box>
                      </ListItem>
                      <ListItem button onClick={handleLogout}>
                        <LogoutIcon sx={{ mr: 1 }} />
                        <ListItemText primary="Logout" />
                      </ListItem>
                    </>
                  ) : (
                    <>
                      <ListItem button component={Link} to="/login">
                        <ListItemText primary="Login" />
                      </ListItem>
                      <ListItem button component={Link} to="/signup">
                        <ListItemText primary="Sign Up" />
                      </ListItem>
                    </>
                  )}
                </List>
              </Box>
            </Drawer>
          </>
        ) : (
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            {navItems.map((item) => (
              <Button
                key={item.text}
                color="inherit"
                component={Link}
                to={item.route}
              >
                {item.text}
              </Button>
            ))}

            {user ? (
              <>
                <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
                  {renderProfileImage()}
                  <Typography variant="body1" sx={{ mx: 1 }}>
                    Hello, {user.username}
                  </Typography>
                  <Button
                    color="inherit"
                    startIcon={<LogoutIcon />}
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </Box>
              </>
            ) : (
              <>
                <Button color="inherit" component={Link} to="/login">
                  Login
                </Button>
                <Button color="inherit" component={Link} to="/signup">
                  Sign Up
                </Button>
              </>
            )}
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;