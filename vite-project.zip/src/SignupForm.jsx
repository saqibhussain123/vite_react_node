import React, { useState } from 'react';
import { Box, Button, TextField, Typography, Paper, Alert, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import bgImage from './assets/2853458.jpg';

export default function SignupForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    role: "user",
    profileImage: null
  });
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'profileImage' && files && files.length > 0) {
      const file = files[0];
      
      // Validate file size (limit to 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError('File size exceeds 5MB limit');
        return;
      }
      
      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
      if (!allowedTypes.includes(file.type)) {
        setError('Only JPEG, PNG, JPG and GIF files are allowed');
        return;
      }
      
      setForm(prev => ({ ...prev, profileImage: file }));
      
      // Clean up previous preview URL to avoid memory leaks
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      
      setPreviewUrl(URL.createObjectURL(file));
      setError('');
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validate form fields
    if (!form.username || !form.email || !form.password) {
      setError('All fields are required');
      setLoading(false);
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      setError('Please enter a valid email address');
      setLoading(false);
      return;
    }

    // Password validation
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters long');
      setLoading(false);
      return;
    }

    const formData = new FormData();
    formData.append('username', form.username);
    formData.append('email', form.email);
    formData.append('password', form.password);
    formData.append('role', form.role);
    if (form.profileImage) {
      formData.append('profileImage', form.profileImage);
    }

    try {
      const response = await axios.post('http://localhost:6969/api/users/register', formData, {
        // headers: {
        //   'Content-Type': 'multipart/form-data'
        // }
      });
      
      console.log('Signup successful:', response.data);
      
      // Clean up preview URL
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      
      // Show success message and redirect to login
      navigate('/login', { state: { message: 'Registration successful! Please log in.' } });
    } catch (error) {
   
      setError(error.response?.data?.error || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      height="100vh"
      sx={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <Paper elevation={4} sx={{ p: 4, width: { xs: '90%', sm: 400 }, maxWidth: '100%', backdropFilter: 'blur(10px)' }}>
        <Typography variant="h5" align="center" gutterBottom fontFamily={'BREE SERIF'}>
          Sign Up
        </Typography>
        
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        
        <Box component="form" onSubmit={handleSubmit} encType="multipart/form-data">
          <TextField
            fullWidth
            label="Username"
            name="username"
            value={form.username}
            onChange={handleChange}
            margin="normal"
            required
            disabled={loading}
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            margin="normal"
            required
            disabled={loading}
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={form.password}
            onChange={handleChange}
            margin="normal"
            required
            disabled={loading}
            helperText="Password must be at least 6 characters"
          />
          <Button
            variant="outlined"
            component="label"
            fullWidth
            sx={{ mt: 2, mb: 2, borderRadius: 2 }}
            disabled={loading}
          >
            {form.profileImage ? 'Change Profile Image' : 'Upload Profile Image'}
            <input
              type="file"
              name="profileImage"
              accept="image/jpeg,image/png,image/jpg,image/gif"
              hidden
              onChange={handleChange}
            />
          </Button>

          {/* Image preview */}
          {previewUrl && (
            <Box textAlign="center" mt={1} mb={2}>
              <img
                src={previewUrl}
                alt="Profile Preview"
                style={{
                  width: 120,
                  height: 120,
                  objectFit: 'cover',
                  borderRadius: '50%',
                  border: '2px solid #1976d2'
                }}
              />
            </Box>
          )}

          <Button 
            variant="contained" 
            fullWidth 
            type="submit" 
            sx={{ mt: 1, borderRadius: 2 }}
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : 'Sign Up'}
          </Button>
        </Box>
        <Typography variant="body2" align="center" mt={2}>
          Already have an account?{' '}
          <Button 
            variant="text" 
            size="small" 
            onClick={() => navigate('/login')}
            disabled={loading}
          >
            Log in
          </Button>
        </Typography>
      </Paper>
    </Box>
  );
}