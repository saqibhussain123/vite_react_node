import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/src/context/AuthContext';
import { api } from '../../utils/api';

const ProgressTracker = () => {
  const { user } = useAuth();
  const [progressEntries, setProgressEntries] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    weight: '',
    bodyFat: '',
    muscle: '',
    measurements: {
      chest: '',
      waist: '',
      hips: '',
      arms: '',
      thighs: ''
    },
    notes: ''
  });
  const chartRef = useRef(null);

  useEffect(() => {
    const loadProgress = async () => {
      try {
        const userProgress = await api.getProgress(user.id);
        setProgressEntries(userProgress.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)));
      } catch (error) {
        console.error('Error loading progress:', error);
      }
    };
    
    if (user) {
      loadProgress();
    }
  }, [user]);

  useEffect(() => {
    // Load Chart.js dynamically if not already loaded
    const loadChart = async () => {
      if (typeof window.Chart === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = () => createChart();
        document.head.appendChild(script);
      } else {
        createChart();
      }
    };

    const createChart = () => {
      if (progressEntries.length > 1 && chartRef.current && window.Chart) {
        const ctx = chartRef.current.getContext('2d');
        
        // Destroy existing chart if it exists
        if (chartRef.current.chart) {
          chartRef.current.chart.destroy();
        }

        const datasets = [];
        
        if (progressEntries.some(entry => entry.weight)) {
          datasets.push({
            label: 'Weight (kg)',
            data: progressEntries.map(entry => entry.weight || null),
            borderColor: '#8B5CF6',
            backgroundColor: '#8B5CF620',
            tension: 0.1,
            spanGaps: true
          });
        }
        
        if (progressEntries.some(entry => entry.bodyFat)) {
          datasets.push({
            label: 'Body Fat (%)',
            data: progressEntries.map(entry => entry.bodyFat || null),
            borderColor: '#F97316',
            backgroundColor: '#F9731620',
            tension: 0.1,
            spanGaps: true
          });
        }

        if (datasets.length > 0) {
          chartRef.current.chart = new Chart(ctx, {
            type: 'line',
            data: {
              labels: progressEntries.map(entry => new Date(entry.createdAt).toLocaleDateString()),
              datasets: datasets
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: false
                }
              },
              plugins: {
                legend: {
                  position: 'top',
                }
              }
            }
          });
        }
      }
    };

    if (progressEntries.length > 1) {
      loadChart();
    }
  }, [progressEntries]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const progressData = {
        ...form,
        weight: form.weight ? parseFloat(form.weight) : null,
        bodyFat: form.bodyFat ? parseFloat(form.bodyFat) : null,
        muscle: form.muscle ? parseFloat(form.muscle) : null,
        measurements: Object.fromEntries(
          Object.entries(form.measurements).map(([key, value]) => [key, value ? parseFloat(value) : null])
        )
      };
      
      const newEntry = await api.createProgress(user.id, progressData);
      setProgressEntries([...progressEntries, newEntry].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)));
      setForm({
        weight: '',
        bodyFat: '',
        muscle: '',
        measurements: {
          chest: '',
          waist: '',
          hips: '',
          arms: '',
          thighs: ''
        },
        notes: ''
      });
      setShowForm(false);
    } catch (error) {
      console.error('Error creating progress entry:', error);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Progress Tracker</h1>
          <p className="text-gray-600 dark:text-gray-400">Monitor your fitness progress over time</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
        >
          📈 Add Progress Entry
        </button>
      </div>

      {/* Progress Chart */}
      {progressEntries.length > 1 && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 mb-8">
          <h2 className="text-xl font-bold mb-4">Progress Chart</h2>
          <div className="h-80">
            <canvas ref={chartRef}></canvas>
          </div>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">Add Progress Entry</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={form.weight}
                    onChange={(e) => setForm({...form, weight: e.target.value})}
                    className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                    placeholder="75.5"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Body Fat (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={form.bodyFat}
                    onChange={(e) => setForm({...form, bodyFat: e.target.value})}
                    className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                    placeholder="15.5"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Muscle Mass (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={form.muscle}
                    onChange={(e) => setForm({...form, muscle: e.target.value})}
                    className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                    placeholder="65.0"
                  />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">Body Measurements (cm)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.keys(form.measurements).map(measurement => (
                    <div key={measurement}>
                      <label className="block text-sm font-medium mb-2 capitalize">{measurement}</label>
                      <input
                        type="number"
                        step="0.1"
                        value={form.measurements[measurement]}
                        onChange={(e) => setForm({
                          ...form, 
                          measurements: {
                            ...form.measurements,
                            [measurement]: e.target.value
                          }
                        })}
                        className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                        placeholder="0.0"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Notes</label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({...form, notes: e.target.value})}
                  className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                  rows="3"
                  placeholder="Any additional notes about your progress..."
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Add Entry
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Progress Entries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {progressEntries.slice().reverse().map(entry => (
          <div key={entry.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="mb-4">
              <h3 className="text-lg font-bold">Progress Entry</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{new Date(entry.createdAt).toLocaleDateString()}</p>
            </div>
            
            <div className="space-y-3">
              {entry.weight && (
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Weight:</span>
                  <span className="font-medium">{entry.weight} kg</span>
                </div>
              )}
              {entry.bodyFat && (
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Body Fat:</span>
                  <span className="font-medium">{entry.bodyFat}%</span>
                </div>
              )}
              {entry.muscle && (
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Muscle Mass:</span>
                  <span className="font-medium">{entry.muscle} kg</span>
                </div>
              )}
            </div>

            {entry.measurements && Object.values(entry.measurements).some(val => val) && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <h4 className="font-medium mb-2">Measurements (cm)</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {Object.entries(entry.measurements).map(([key, value]) => 
                    value && (
                      <div key={key} className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400 capitalize">{key}:</span>
                        <span>{value}</span>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}

            {entry.notes && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <p className="text-sm text-gray-600 dark:text-gray-400">{entry.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {progressEntries.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📈</div>
          <h3 className="text-xl font-medium mb-2">No progress entries yet</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Start tracking your fitness progress by adding your first entry!</p>
          <button
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
          >
            Add Your First Entry
          </button>
        </div>
      )}
    </div>
  );
};

export default ProgressTracker;