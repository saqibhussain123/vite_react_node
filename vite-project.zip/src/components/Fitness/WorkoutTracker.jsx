import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/src/context/AuthContext';
import { api } from '../../utils/api';

const WorkoutTracker = () => {
  const { user } = useAuth();
  const [workouts, setWorkouts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: '',
    category: 'strength',
    exercises: [{ name: '', sets: '', reps: '', weight: '', notes: '' }]
  });

  useEffect(() => {
    const loadWorkouts = async () => {
      try {
        const userWorkouts = await api.getWorkouts(user.id);
        setWorkouts(userWorkouts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
      } catch (error) {
        console.error('Error loading workouts:', error);
      }
    };
    
    if (user) {
      loadWorkouts();
    }
  }, [user]);

  const addExercise = () => {
    setForm({
      ...form,
      exercises: [...form.exercises, { name: '', sets: '', reps: '', weight: '', notes: '' }]
    });
  };

  const removeExercise = (index) => {
    if (form.exercises.length > 1) {
      const newExercises = form.exercises.filter((_, i) => i !== index);
      setForm({ ...form, exercises: newExercises });
    }
  };

  const updateExercise = (index, field, value) => {
    const updatedExercises = [...form.exercises];
    updatedExercises[index][field] = value;
    setForm({ ...form, exercises: updatedExercises });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newWorkout = await api.createWorkout(user.id, form);
      setWorkouts([newWorkout, ...workouts]);
      setForm({
        name: '',
        category: 'strength',
        exercises: [{ name: '', sets: '', reps: '', weight: '', notes: '' }]
      });
      setShowForm(false);
    } catch (error) {
      console.error('Error creating workout:', error);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Workout Tracker</h1>
          <p className="text-gray-600 dark:text-gray-400">Plan and track your workout routines</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
        >
          ➕ Add Workout
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">Create New Workout</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Workout Name</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({...form, name: e.target.value})}
                  className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                  placeholder="e.g., Upper Body Strength"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({...form, category: e.target.value})}
                  className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                >
                  <option value="strength">Strength Training</option>
                  <option value="cardio">Cardio</option>
                  <option value="flexibility">Flexibility</option>
                  <option value="sports">Sports</option>
                </select>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Exercises</h3>
                  <button
                    type="button"
                    onClick={addExercise}
                    className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm"
                  >
                    + Add Exercise
                  </button>
                </div>
                {form.exercises.map((exercise, index) => (
                  <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 mb-4">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium">Exercise {index + 1}</h4>
                      {form.exercises.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeExercise(index)}
                          className="text-red-500 hover:text-red-700 text-sm"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Exercise name"
                        value={exercise.name}
                        onChange={(e) => updateExercise(index, 'name', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                        required
                      />
                      <input
                        type="number"
                        placeholder="Sets"
                        value={exercise.sets}
                        onChange={(e) => updateExercise(index, 'sets', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Reps"
                        value={exercise.reps}
                        onChange={(e) => updateExercise(index, 'reps', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Weight (kg)"
                        value={exercise.weight}
                        onChange={(e) => updateExercise(index, 'weight', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Notes (optional)"
                      value={exercise.notes}
                      onChange={(e) => updateExercise(index, 'notes', e.target.value)}
                      className="w-full mt-3 px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                ))}
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Create Workout
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Workouts List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {workouts.map(workout => (
          <div key={workout.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold">{workout.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{workout.category}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">{new Date(workout.createdAt).toLocaleDateString()}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                workout.category === 'strength' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' :
                workout.category === 'cardio' ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' :
                workout.category === 'flexibility' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
              }`}>
                {workout.category}
              </span>
            </div>
            <div className="space-y-2">
              {workout.exercises.map((exercise, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <span className="font-medium">{exercise.name}</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {exercise.sets && exercise.reps && `${exercise.sets}×${exercise.reps}`}
                    {exercise.weight && ` @ ${exercise.weight}kg`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {workouts.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">💪</div>
          <h3 className="text-xl font-medium mb-2">No workouts yet</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Start tracking your fitness journey by adding your first workout!</p>
          <button
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
          >
            Create Your First Workout
          </button>
        </div>
      )}
    </div>
  );
};

export default WorkoutTracker;