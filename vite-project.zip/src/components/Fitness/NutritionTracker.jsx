import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/src/context/AuthContext';
import { api } from '../../utils/api';

const NutritionTracker = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    mealType: 'breakfast',
    foodItems: [{ name: '', quantity: '', calories: '', protein: '', carbs: '', fat: '' }]
  });

  useEffect(() => {
    const loadNutrition = async () => {
      try {
        const userNutrition = await api.getNutrition(user.id);
        setEntries(userNutrition.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
      } catch (error) {
        console.error('Error loading nutrition:', error);
      }
    };
    
    if (user) {
      loadNutrition();
    }
  }, [user]);

  const addFoodItem = () => {
    setForm({
      ...form,
      foodItems: [...form.foodItems, { name: '', quantity: '', calories: '', protein: '', carbs: '', fat: '' }]
    });
  };

  const removeFoodItem = (index) => {
    if (form.foodItems.length > 1) {
      const newItems = form.foodItems.filter((_, i) => i !== index);
      setForm({ ...form, foodItems: newItems });
    }
  };

  const updateFoodItem = (index, field, value) => {
    const updatedItems = [...form.foodItems];
    updatedItems[index][field] = value;
    setForm({ ...form, foodItems: updatedItems });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newEntry = await api.createNutrition(user.id, form);
      setEntries([newEntry, ...entries]);
      setForm({
        mealType: 'breakfast',
        foodItems: [{ name: '', quantity: '', calories: '', protein: '', carbs: '', fat: '' }]
      });
      setShowForm(false);
    } catch (error) {
      console.error('Error creating nutrition entry:', error);
    }
  };

  const getTotalCalories = (entry) => {
    return entry.foodItems.reduce((total, item) => total + (parseInt(item.calories) || 0), 0);
  };

  const getMealIcon = (mealType) => {
    const icons = {
      breakfast: '🌅',
      lunch: '☀️',
      dinner: '🌙',
      snack: '🍿'
    };
    return icons[mealType] || '🍽️';
  };

  const getMealColors = (mealType) => {
    const colors = {
      breakfast: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      lunch: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      dinner: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      snack: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
    };
    return colors[mealType] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Nutrition Tracker</h1>
          <p className="text-gray-600 dark:text-gray-400">Monitor your daily food intake and nutrition</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
        >
          🍽️ Log Meal
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">Log Meal</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Meal Type</label>
                <select
                  value={form.mealType}
                  onChange={(e) => setForm({...form, mealType: e.target.value})}
                  className="w-full px-4 py-2 text-base rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                >
                  <option value="breakfast">🌅 Breakfast</option>
                  <option value="lunch">☀️ Lunch</option>
                  <option value="dinner">🌙 Dinner</option>
                  <option value="snack">🍿 Snack</option>
                </select>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Food Items</h3>
                  <button
                    type="button"
                    onClick={addFoodItem}
                    className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm"
                  >
                    + Add Food Item
                  </button>
                </div>
                {form.foodItems.map((item, index) => (
                  <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 mb-4">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium">Food Item {index + 1}</h4>
                      {form.foodItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeFoodItem(index)}
                          className="text-red-500 hover:text-red-700 text-sm"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      <input
                        type="text"
                        placeholder="Food name"
                        value={item.name}
                        onChange={(e) => updateFoodItem(index, 'name', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                        required
                      />
                      <input
                        type="text"
                        placeholder="Quantity (e.g., 1 cup)"
                        value={item.quantity}
                        onChange={(e) => updateFoodItem(index, 'quantity', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Calories"
                        value={item.calories}
                        onChange={(e) => updateFoodItem(index, 'calories', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Protein (g)"
                        value={item.protein}
                        onChange={(e) => updateFoodItem(index, 'protein', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Carbs (g)"
                        value={item.carbs}
                        onChange={(e) => updateFoodItem(index, 'carbs', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                      <input
                        type="number"
                        placeholder="Fat (g)"
                        value={item.fat}
                        onChange={(e) => updateFoodItem(index, 'fat', e.target.value)}
                        className="px-3 py-2 text-base rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Log Meal
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-2 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Nutrition Entries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {entries.map(entry => (
          <div key={entry.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold capitalize flex items-center">
                  <span className="mr-2">{getMealIcon(entry.mealType)}</span>
                  {entry.mealType}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{new Date(entry.createdAt).toLocaleDateString()}</p>
                <p className="text-lg font-medium text-orange-500">{getTotalCalories(entry)} calories</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getMealColors(entry.mealType)}`}>
                {entry.mealType}
              </span>
            </div>
            <div className="space-y-2">
              {entry.foodItems.map((item, index) => (
                <div key={index} className="flex justify-between items-start p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex-1">
                    <span className="font-medium">{item.name}</span>
                    {item.quantity && <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">({item.quantity})</span>}
                    {(item.protein || item.carbs || item.fat) && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {item.protein && `P: ${item.protein}g `}
                        {item.carbs && `C: ${item.carbs}g `}
                        {item.fat && `F: ${item.fat}g`}
                      </div>
                    )}
                  </div>
                  <span className="text-sm font-medium">{item.calories || 0} cal</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {entries.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🥗</div>
          <h3 className="text-xl font-medium mb-2">No meals logged yet</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Start tracking your nutrition by logging your first meal!</p>
          <button
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
          >
            Log Your First Meal
          </button>
        </div>
      )}
    </div>
  );
};

export default NutritionTracker;