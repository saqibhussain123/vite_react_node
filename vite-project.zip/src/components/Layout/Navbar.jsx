import React from 'react';
import { useAuth } from '../../context/src/context/AuthContext';

const Navbar = ({ currentRoute, onRouteChange }) => {
  const { user, logout } = useAuth();

// Add this to your existing Navbar component, in the navItems array:

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: '📊' },
  { id: 'workouts', label: 'Workouts', icon: '💪' },
  { id: 'nutrition', label: 'Nutrition', icon: '🥗' },
  { id: 'progress', label: 'Progress', icon: '📈' },
  // Add admin link only for admin users
  ...(user?.role === 'admin' ? [{ id: 'admin', label: 'Admin', icon: '👑' }] : [])
];

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700 fixed w-full top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-purple-600 cursor-pointer" onClick={() => onRouteChange('dashboard')}>
                🏋️ FitTracker
              </h1>
            </div>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => onRouteChange(item.id)}
                  className={`inline-flex items-center px-1 pt-1 text-sm font-medium transition-colors duration-200 ${
                    currentRoute === item.id
                      ? 'text-purple-600 border-b-2 border-purple-600'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <span className="mr-2">{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {user && (
              <>
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-medium">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm font-medium hidden sm:block">{user.username}</span>
                </div>
                <button
                  onClick={logout}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 text-sm"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
        
        {/* Mobile Navigation */}
        <div className="md:hidden border-t border-gray-200 dark:border-gray-700">
          <div className="px-2 py-3 space-y-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => onRouteChange(item.id)}
                className={`flex items-center w-full px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentRoute === item.id
                    ? 'bg-purple-600 text-white'
                    : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <span className="mr-2">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>
        </div>
            </div>
      </nav>
    
    );
};

export default Navbar;