import React from "react";
import { useAuth } from "../../context/src/context/AuthContext";

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-2xl font-medium">Loading...</div>
      </div>
    );
  }

  return user ? children : null;
};

export default ProtectedRoute;