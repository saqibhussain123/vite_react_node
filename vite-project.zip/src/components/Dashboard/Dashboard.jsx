import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/src/context/AuthContext';
import { api } from '../../utils/api';

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalWorkouts: 0,
    totalCalories: 0,
    currentWeight: 0,
    weeklyGoal: 5
  });
  const [recentActivities, setRecentActivities] = useState([]);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const workouts = await api.getWorkouts(user.id);
        const nutrition = await api.getNutrition(user.id);
        const progress = await api.getProgress(user.id);
        
        const totalCalories = nutrition.reduce((sum, entry) => {
          return sum + entry.foodItems.reduce((itemSum, item) => itemSum + (item.calories || 0), 0);
        }, 0);
        
        const latestProgress = progress.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
        
        setStats({
          totalWorkouts: workouts.length,
          totalCalories: totalCalories,
          currentWeight: latestProgress?.weight || 0,
          weeklyGoal: 5
        });
        
        // Create recent activities
        const activities = [];
        
        workouts.slice(0, 2).forEach(workout => {
          activities.push({
            id: 'workout_' + workout.id,
            type: 'workout',
            description: `Completed ${workout.name}`,
            time: new Date(workout.createdAt).toLocaleDateString()
          });
        });
        
        nutrition.slice(0, 2).forEach(entry => {
          const totalCals = entry.foodItems.reduce((sum, item) => sum + (item.calories || 0), 0);
          activities.push({
            id: 'nutrition_' + entry.id,
            type: 'nutrition',
            description: `Logged ${entry.mealType} - ${totalCals} calories`,
            time: new Date(entry.createdAt).toLocaleDateString()
          });
        });
        
        setRecentActivities(activities.slice(0, 5));
        
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      }
    };
    
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {user.username}! 👋</h1>
        <p className="text-gray-600 dark:text-gray-400">Track your fitness journey and achieve your goals</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Total Workouts</p>
              <p className="text-3xl font-bold text-purple-600">{stats.totalWorkouts}</p>
            </div>
            <div className="text-4xl">💪</div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Total Calories</p>
              <p className="text-3xl font-bold text-orange-500">{stats.totalCalories.toLocaleString()}</p>
            </div>
            <div className="text-4xl">🔥</div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Current Weight</p>
              <p className="text-3xl font-bold text-green-500">{stats.currentWeight || '--'} kg</p>
            </div>
            <div className="text-4xl">⚖️</div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Weekly Goal</p>
              <p className="text-3xl font-bold text-purple-600">{Math.min(stats.totalWorkouts, stats.weeklyGoal)}/{stats.weeklyGoal}</p>
            </div>
            <div className="text-4xl">🎯</div>
          </div>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
        <h2 className="text-xl font-bold mb-4">Recent Activities</h2>
        {recentActivities.length > 0 ? (
          <div className="space-y-4">
            {recentActivities.map(activity => (
              <div key={activity.id} className="flex items-center space-x-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-2xl">
                  {activity.type === 'workout' && '💪'}
                  {activity.type === 'nutrition' && '🥗'}
                  {activity.type === 'progress' && '📈'}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{activity.description}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-4xl mb-4">🌟</div>
            <p className="text-gray-600 dark:text-gray-400">Start your fitness journey by logging your first workout!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;